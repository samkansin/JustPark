package th.co.scb.ssp.webcustomerregister.lib.db;

import com.zaxxer.hikari.HikariDataSource;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import th.co.scb.ssp.webcustomerregister.lib.vault.VaultConfig;

import javax.sql.DataSource;

@Configuration
@Slf4j
@RequiredArgsConstructor
public class DataSourcesConfig {
    private final VaultConfig vaultConfig;

    @Bean
    public DataSource dataSource(@Value("${mssql.connection-params}") String mssqlConnectionParams, @Value("${mssql.idle-pool-size}") int mssqlIdlePoolSize, @Value("${mssql.max-pool-size}") int mssqlMaxPoolSize) {
        log.debug("Configure MS SQL Server Using Spring Boot Properties");
        final String username = vaultConfig.get(VaultConfig.DB_USR);
        final String password = vaultConfig.get(VaultConfig.DB_PWD);
        final String dbName = vaultConfig.get(VaultConfig.DB_NAME);
        final String port = vaultConfig.get(VaultConfig.DB_PORT);
        final String host = vaultConfig.get(VaultConfig.DB_HOST);
        final String url = host + ":" + port;
        final String jdbcUrl = "jdbc:sqlserver://" + url + ";databaseName=" + dbName + mssqlConnectionParams;
        HikariDataSource ds = new HikariDataSource();
        ds.setDriverClassName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        ds.setUsername(username);
        ds.setPassword(password);
        ds.setJdbcUrl(jdbcUrl);
        ds.setMinimumIdle(mssqlIdlePoolSize);
        ds.setMaximumPoolSize(mssqlMaxPoolSize);
        return ds;
    }
}