package th.co.scb.ssp.webcustomerregister.lib.vault;

import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.apache.hc.core5.util.Asserts;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.vault.core.VaultTemplate;
import org.springframework.vault.core.VaultTransitOperations;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

@Slf4j
@Component
public class VaultConfig {

    // Available Configs
    public static final String DB_USR = "db.username";
    public static final String DB_PWD = "db.password";
    public static final String DB_NAME = "db.name";
    public static final String DB_PORT = "db.port";

    // Todo: load secret from vault
    public static final String DB_HOST = "db.host";
    private final Map<String, String> configs = new HashMap<>();
    @Value("${vault.project.name}")
    private String vaultProjectName;
    @Autowired(required = false)
    private VaultTemplate vaultTemplate;
    @Autowired
    private Environment env;

    @PostConstruct
    private void postConstruct() {

        Asserts.notNull(get(DB_USR), "DB_USR");
        Asserts.notNull(get(DB_PWD), "DB_PWD");
        Asserts.notNull(get(DB_NAME), "DB_NAME");
        Asserts.notNull(get(DB_PORT), "DB_PORT");
        Asserts.notNull(get(DB_HOST), "DB_HOST");
    }

    public String vault(String vaultKey) {
        VaultTransitOperations transitOperations = vaultTemplate.opsForTransit("transit");
        return transitOperations.decrypt(vaultProjectName, Objects.requireNonNull(env.getProperty(vaultKey)));
    }

    public String get(String vaultKey) {
        if (configs.containsKey(vaultKey)) {
            log.debug("config from cache !");
        } else {
            final String propConfig = "vault." + vaultKey;
            final String values = env.getProperty(propConfig);
            if (values != null) {
                log.debug("get config from application property key {}", propConfig);
                configs.put(vaultKey, values);
            } else {
                log.debug("get config from vault key {}", vaultKey);
                configs.put(vaultKey, vault(vaultKey));
            }
        }
        return configs.get(vaultKey);
    }

}
