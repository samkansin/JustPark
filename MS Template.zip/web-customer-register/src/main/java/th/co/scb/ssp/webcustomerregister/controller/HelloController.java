package th.co.scb.ssp.webcustomerregister.controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import th.co.scb.ssp.common.lib.lookup.LookupType;

import java.time.LocalDateTime;

import static th.co.scb.ssp.common.lib.lookup.constant.LookupConstant.DEFAULT_LOOKUP_TYPE;

@Slf4j
@RestController
@LookupType(DEFAULT_LOOKUP_TYPE)
public class HelloController {

    @GetMapping("/")
    public String index() {

        return ("HelloController: " + LocalDateTime.now());
    }
}
