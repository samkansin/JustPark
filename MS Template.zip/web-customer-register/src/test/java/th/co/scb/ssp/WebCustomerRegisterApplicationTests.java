package th.co.scb.ssp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebCustomerRegisterApplicationTests {

	@Test
	void contextLoads() {
	}

}
